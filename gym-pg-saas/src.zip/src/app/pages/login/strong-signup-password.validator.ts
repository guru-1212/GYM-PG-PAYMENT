import { AbstractControl, ValidationErrors } from '@angular/forms';

export function strongPasswordValidator(control: AbstractControl): ValidationErrors | null {
  const value = control.value;
  if (!value) {
    return null;
  }

  const missing: { [key: string]: boolean } = {};

  if (!/[A-Z]/.test(value)) {
    missing['uppercase'] = true;
  }
  if (!/[a-z]/.test(value)) {
    missing['lowercase'] = true;
  }
  if (!/[0-9]/.test(value)) {
    missing['digit'] = true;
  }
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    missing['special'] = true;
  }
  if (value.length < 8) {
    missing['length'] = true;
  }

  return Object.keys(missing).length > 0 ? { strongPassword: missing } : null;
}
