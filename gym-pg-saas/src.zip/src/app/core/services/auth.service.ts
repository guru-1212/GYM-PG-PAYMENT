import { Injectable, computed, inject, signal } from '@angular/core';
import { PermissionService } from './permission.service';

import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  deleteUser,
  
  sendPasswordResetEmail as fbSendPasswordResetEmail,
} from 'firebase/auth';
import {
  doc,
  DocumentSnapshot,
  getDoc,
  onSnapshot,
  serverTimestamp,

  writeBatch,
} from 'firebase/firestore';
import { Owner, OwnerRole, OwnerStatus } from '../models/owner.model';
import { FirebaseAppService } from './firebase-app.service';

const OWNER_LOGIN_ALIASES_COLLECTION = 'ownerLoginAliases';
const OWNER_PHONE_LOGIN_ALIASES_COLLECTION = 'ownerPhoneLoginAliases';

function normalizeRole(v: unknown): OwnerRole | '' {
  const s = String(v ?? '')
    .toLowerCase()
    .trim();
  if (s === 'admin' || s === 'owner') return s;
  return s as OwnerRole;
}

function normalizeStatus(v: unknown): OwnerStatus | '' {
  const s = String(v ?? '')
    .toLowerCase()
    .trim();
  if (s === 'pending' || s === 'approved' || s === 'rejected' || s === 'inactive') return s;
  return s as OwnerStatus;
}

function ownerFromSnapshot(snap: DocumentSnapshot): Owner | null {
  if (!(snap as any).exists()) return null;
  const raw = snap.data() as Record<string, unknown>;
  return {
    ...(raw as unknown as Owner),
    ownerId: snap.id,
    role: normalizeRole(raw['role']) as Owner['role'],
    status: normalizeStatus(raw['status']) as Owner['status'],
  };
}

/** Auth email stored on alias docs: field name must match Firestore rules (`email` on phone aliases). */
function readAliasAuthEmail(data: Record<string, unknown>): string | null {
  const v = data['email'] ?? data['authLoginEmail'];
  return typeof v === 'string' && v.includes('@') ? v.trim().toLowerCase() : null;
}

/** Result of reading `owners/{uid}` (used for login toasts / console — not an HTTP error when doc is missing). */
export type ProfileLoadResult = {
  owner: Owner | null;
  uid: string | null;
  problem?: 'no-signed-in-user' | 'no-firestore-document' | 'permission-denied' | 'fetch-failed';
};

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly fb = inject(FirebaseAppService);
  private permissionService = inject(PermissionService);
  readonly user = signal<User | null>(null);
  readonly profile = signal<Owner | null>(null);
  readonly loading = signal(true);

  readonly isAdmin = computed(() => this.profile()?.role === 'admin');
  readonly isApprovedOwner = computed(
    () => this.profile()?.role === 'owner' && this.profile()?.status === 'approved',
  );
  readonly isSubscriptionValid = computed(() => {
    const profile = this.profile();
    if (!profile || !profile.planEndDate) return false;
    const planEndDate = profile.planEndDate.toDate?.() || new Date(profile.planEndDate as any);
    return new Date() <= planEndDate;
  });

  private profileUnsub: (() => void) | null = null;
  private profileListenerUid: string | null = null;

  constructor() {
    onAuthStateChanged(this.fb.auth, (u) => {
      this.user.set(u);

      if (!u) {
        this.profileUnsub?.();
        this.profileUnsub = null;
        this.profileListenerUid = null;
        this.profile.set(null);
        this.loading.set(false);
        return;
      }

      if (this.profileListenerUid === u.uid && this.profileUnsub) {
        this.loading.set(false);
        return;
      }

      this.profileUnsub?.();
      this.profileUnsub = null;
      this.profileListenerUid = u.uid;

      const ref = doc(this.fb.db, 'owners', u.uid);
          this.profileUnsub = onSnapshot(ref, (snap: any) => {
        const o = ownerFromSnapshot(snap);
        this.profile.set(o);

        if (o) {
          this.permissionService.setRole('owner');
          this.permissionService.setOwnerFeatures(o.features);
        }
      });
    });
  }

  /**
   * Email: Firebase email/password, with optional `ownerLoginAliases` retry for legacy mapped emails.
   * Mobile: digits-only key → `ownerPhoneLoginAliases/{digits}` → `email` field → signInWithEmailAndPassword.
   * No Firebase Phone Auth / OTP / synthetic Auth emails.
   */
  async signIn(identifier: string, password: string): Promise<void> {
    const id = identifier.trim();
    if (id.includes('@')) {
      try {
        await signInWithEmailAndPassword(this.fb.auth, id, password);
      } catch (e) {
        if (!this.isAuthRetryableForAlias(e)) throw e;
        const resolved = await this.getAuthEmailForContactLogin(id);
        if (!resolved || resolved === normalizeOwnerLoginEmailKey(id)) throw e;
        await signInWithEmailAndPassword(this.fb.auth, resolved, password);
      }
    } else {
      const n = normalizeOwnerPhone(id);
      if (!n) {
        const err = new Error('Invalid mobile number');
        (err as { code?: string }).code = 'auth/invalid-phone-number';
        throw err;
      }
      const phoneDigits = digitsOnly(n);
      if (phoneDigits.length < 10) {
        const err = new Error('Invalid mobile number');
        (err as { code?: string }).code = 'auth/invalid-phone-number';
        throw err;
      }
      const loginEmail = await this.getLoginEmailFromPhoneAliasDoc(phoneDigits);
      if (!loginEmail) {
        const err = new Error('Phone not registered. Sign up first or sign in with your email.');
        (err as { code?: string }).code = 'auth/phone-not-registered';
        throw err;
      }
      await signInWithEmailAndPassword(this.fb.auth, loginEmail, password);
    }
    // Wait for auth state to propagate
    await new Promise<void>((resolve) => {
      const unsub = onAuthStateChanged(this.fb.auth, () => {
        unsub();
        resolve();
      });
    });
  }

  private isAuthRetryableForAlias(e: unknown): boolean {
    const code = e && typeof e === 'object' && 'code' in e ? String((e as { code: string }).code) : '';
    return (
      code === 'auth/user-not-found' ||
      code === 'auth/wrong-password' ||
      code === 'auth/invalid-credential' ||
      code === 'auth/invalid-email'
    );
  }

  /** Optional legacy: ownerLoginAliases/{lowercaseEmail} → email (or authLoginEmail) = Auth login email. */
  private async getAuthEmailForContactLogin(trimmedEmail: string): Promise<string | null> {
    const key = normalizeOwnerLoginEmailKey(trimmedEmail);
    if (!key.includes('@')) return null;
    try {
      const snap = await getDoc(doc(this.fb.db, OWNER_LOGIN_ALIASES_COLLECTION, key));
      if (!(snap as any).exists()) return null;
      return readAliasAuthEmail((snap as any).data() as Record<string, unknown>);
    } catch {
      return null;
    }
  }

  /** `ownerPhoneLoginAliases/{phoneDigits}` → `email` (Firebase Auth email for password sign-in). */
  private async getLoginEmailFromPhoneAliasDoc(phoneDigits: string): Promise<string | null> {
    try {
      const snap = await getDoc(doc(this.fb.db, OWNER_PHONE_LOGIN_ALIASES_COLLECTION, phoneDigits));
      if (!(snap as any).exists()) return null;
      return readAliasAuthEmail((snap as any).data() as Record<string, unknown>);
    } catch {
      return null;
    }
  }

  async sendOwnerPasswordReset(identifier: string): Promise<void> {
    const id = identifier.trim();
    let email: string;
    if (id.includes('@')) {
      // Use the exact email entered for reset; avoids stale alias mapping issues.
      email = normalizeOwnerLoginEmailKey(id);
    } else {
      const n = normalizeOwnerPhone(id);
      if (!n) {
        const err = new Error('Invalid mobile number');
        (err as { code?: string }).code = 'auth/invalid-phone-number';
        throw err;
      }
      const resolved = await this.getLoginEmailFromPhoneAliasDoc(digitsOnly(n));
      if (!resolved) {
        const err = new Error('Phone not registered.');
        (err as { code?: string }).code = 'auth/phone-not-registered';
        throw err;
      }
      email = resolved;
    }
    // Temporary debug: compare these values with the reset-link URL query (`apiKey`) and host.
    // Remove after diagnosing "expired / already used" behavior.
    const opts = (this.fb.app as any).options;
    console.info('[AuthDebug][PasswordReset][send]', {
      identifier: id,
      resolvedEmail: email,
      firebaseProjectId: opts.projectId,
      firebaseAuthDomain: opts.authDomain,
      firebaseApiKeyTail: typeof opts.apiKey === 'string' ? opts.apiKey.slice(-6) : '',
      sentAtIso: new Date().toISOString(),
    });
    await fbSendPasswordResetEmail(this.fb.auth, email);
  }

  /** Legacy no-op (older UI called this around phone OTP). */
  disposeOwnerSignUpPhone(): void {}

  /**
   * Sign-up: createUserWithEmailAndPassword, then owners + ownerPhoneLoginAliases in one batch.
   * Phone alias doc uses field `email` to match your security rules.
   */
  async completeOwnerSignUpWithEmailPassword(args: {
    contactEmail: string;
    password: string;
    name: string;
    businessName: string;
    businessType: 'gym' | 'pg';
    phoneE164: string;
  }): Promise<void> {
    const emailNorm = args.contactEmail.trim().toLowerCase();
    const phoneDigits = digitsOnly(args.phoneE164);
    if (phoneDigits.length < 10) {
      const err = new Error('Invalid mobile number');
      (err as { code?: string }).code = 'auth/invalid-phone-number';
      throw err;
    }

    const phoneAliasSnap = await getDoc(doc(this.fb.db, OWNER_PHONE_LOGIN_ALIASES_COLLECTION, phoneDigits));
    // @ts-ignore
    if (phoneAliasSnap.exists()) {
      const err = new Error('Phone already registered');
      (err as { code?: string }).code = 'auth/credential-already-in-use';
      throw err;
    }

    const cred = await createUserWithEmailAndPassword(this.fb.auth, emailNorm, args.password);
    const uid = cred.user.uid;
    try {
      const batch = writeBatch(this.fb.db);

      batch.set(doc(this.fb.db, 'owners', uid), {
        ownerId: uid,
        name: args.name.trim(),
        businessName: args.businessName.trim(),
        email: emailNorm,
        businessType: args.businessType,
        role: 'owner',
        status: 'pending',
        complaintEnabled: false,
        createdAt: serverTimestamp(),
      });

      batch.set(
        doc(this.fb.db, OWNER_PHONE_LOGIN_ALIASES_COLLECTION, phoneDigits),
        {
          ownerId: uid,
          email: emailNorm,
          authLoginEmail: emailNorm,
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );

      batch.set(
        doc(this.fb.db, OWNER_LOGIN_ALIASES_COLLECTION, emailNorm),
        {
          ownerId: uid,
          email: emailNorm,
          authLoginEmail: emailNorm,
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );

      await batch.commit();
    } catch (e) {
      // Avoid orphaned Auth users when Firestore create is denied (rules) or fails
      try {
        await deleteUser(cred.user);
      } catch {
        /* ignore */
      }
      throw e;
    }
  }

  /** Legacy signup entry point used by current login page. */
  async signUp(
    email: string,
    password: string,
    name: string,
    businessName: string,
    businessType: 'gym' | 'pg',
  ): Promise<void> {
    const emailNorm = normalizeOwnerLoginEmailKey(email);
    const cred = await createUserWithEmailAndPassword(this.fb.auth, emailNorm, password);
    const uid = cred.user.uid;
    try {
      const batch = writeBatch(this.fb.db);
      const ownerRef = doc(this.fb.db, 'owners', uid);
      // Core fields + app routing (role/status/business*) — phone stored digits-only per product spec.
      batch.set(ownerRef, {
        ownerId: uid,
        name: name.trim(),
        businessName: businessName.trim(),
        email: emailNorm,
        businessType,
        role: 'owner',
        status: 'pending',
        complaintEnabled: false,
        phoneVerified: false,
        createdAt: serverTimestamp(),
      });
      batch.set(doc(this.fb.db, OWNER_PHONE_LOGIN_ALIASES_COLLECTION), {
        email: emailNorm,
      });
      await batch.commit();
    } catch (e) {
      try {
        await deleteUser(cred.user);
      } catch {
        /* ignore */
      }
      throw e;
    }
  }

  async signOut(): Promise<void> {
    await signOut(this.fb.auth);
  }

  async refreshProfile(): Promise<Owner | null> {
    const r = await this.loadProfileOnce();
    return r.owner;
  }

  async loadProfileOnce(): Promise<ProfileLoadResult> {
    // Wait for auth state to be initialized
    await new Promise<void>((resolve) => {
      const unsub = onAuthStateChanged(this.fb.auth, () => {
        unsub();
        resolve();
      });
    });
    
    const u = this.fb.auth.currentUser;
    if (!u) {
      this.profile.set(null);
      return { owner: null, uid: null, problem: 'no-signed-in-user' };
    }

    const uid = u.uid;

    try {
      const snap = await getDoc(doc(this.fb.db, 'owners', uid));
      // @ts-ignore
      if (!snap.exists()) {
        this.profile.set(null);
        return { owner: null, uid, problem: 'no-firestore-document' };
      }

      const o = ownerFromSnapshot(snap);
      if (o) {
        this.profile.set(o);
      }
      return { owner: o, uid };
    } catch (e: unknown) {
      const code =
        e && typeof e === 'object' && 'code' in e ? String((e as { code: string }).code) : '';
      this.profile.set(null);
      const problem = code === 'permission-denied' ? 'permission-denied' : 'fetch-failed';
      return { owner: null, uid, problem };
    }
  }
}

function normalizeOwnerLoginEmailKey(id: string): string {
  return String(id ?? '')
    .trim()
    .toLowerCase();
}

function digitsOnly(v: unknown): string {
  return String(v ?? '').replace(/\D/g, '');
}

function normalizeOwnerPhone(id: string): string | null {
  let d = digitsOnly(id);
  if (d.length === 12 && d.startsWith('91')) d = d.slice(2);
  if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  return d.length === 10 ? d : null;
}
